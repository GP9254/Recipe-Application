# Recipe App - Flutter UI

## [Watch it on YouTube](https://youtu.be/kkorXiCKhAY)

## Also work on both landscape and portrait mood

**Packages we are using:**

- flutter_svg: [link](https://pub.dev/packages/flutter_svg)
- provider: [link](https://pub.dev/packages/provider)

Try to create a Recepie App, Which includes almost all impotant pages like Home page, recipe bundel page then list of recipes also profile page and many more.

### Furniture App Final UI

![Preview](part_1.gif)

## Part 1

![App UI](/ui.png)

Design by- Gautam Patel